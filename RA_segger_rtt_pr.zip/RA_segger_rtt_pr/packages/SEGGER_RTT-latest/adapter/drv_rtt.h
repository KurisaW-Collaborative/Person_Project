/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2022-09-29     ASUS       the first version
 */
#ifndef PACKAGES_SEGGER_RTT_LATEST_ADAPTER_DRV_RTT_H_
#define PACKAGES_SEGGER_RTT_LATEST_ADAPTER_DRV_RTT_H_




#endif /* PACKAGES_SEGGER_RTT_LATEST_ADAPTER_DRV_RTT_H_ */
